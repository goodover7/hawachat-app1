// Service Worker — هوا شات v7 PRE-COMPRESSED
// entry.js مرفوع كـ gzip مسبقاً → Content-Encoding: gzip من _headers
// cache-first للـ bundle + assets، network-only للـ API

const CACHE_NAME    = 'hawa-v7-static';
const RUNTIME_CACHE = 'hawa-v7-runtime';

const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/logo.png',
  '/manifest.json',
];

self.addEventListener('install', function(e) {
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(PRECACHE_URLS).catch(function() {});
    })
  );
});

self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(names) {
      return Promise.all(
        names
          .filter(function(n) { return n !== CACHE_NAME && n !== RUNTIME_CACHE; })
          .map(function(n) { return caches.delete(n); })
      );
    }).then(function() { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function(e) {
  if (e.request.method !== 'GET') return;
  var url = e.request.url;

  // شبكة-فقط: Supabase + APIs + خارجي
  if (
    url.includes('supabase.co') || url.includes('supabase.in') ||
    url.includes('youtube')     || url.includes('googleapis') ||
    url.includes('s3cdn')       || url.includes('miaoda')
  ) return;

  // bundle JS الرئيسي: cache-first
  if (url.includes('/_expo/static/js/web/entry-')) {
    e.respondWith(
      caches.match(e.request).then(function(cached) {
        if (cached) return cached;
        return fetch(e.request).then(function(resp) {
          if (resp && resp.status === 200) {
            var clone = resp.clone();
            caches.open(CACHE_NAME).then(function(c) { c.put(e.request, clone); });
          }
          return resp;
        }).catch(function() { return caches.match('/'); });
      })
    );
    return;
  }

  // أصول ثابتة: cache-first
  if (
    url.includes('/_expo/static/') ||
    url.includes('/assets/')       ||
    url.includes('/fonts/')        ||
    url.match(/\.(png|jpg|jpeg|webp|svg|woff2?|ttf|otf|ico)(\?.*)?$/)
  ) {
    e.respondWith(
      caches.match(e.request).then(function(cached) {
        if (cached) return cached;
        return fetch(e.request).then(function(resp) {
          if (resp && resp.status === 200) {
            var clone = resp.clone();
            caches.open(RUNTIME_CACHE).then(function(c) { c.put(e.request, clone); });
          }
          return resp;
        });
      })
    );
    return;
  }

  // HTML: network-first مع fallback
  if (url.endsWith('/') || url.includes('/index.html') || !url.includes('.')) {
    e.respondWith(
      fetch(e.request).then(function(resp) {
        if (resp && resp.status === 200) {
          var clone = resp.clone();
          caches.open(CACHE_NAME).then(function(c) { c.put(e.request, clone); });
        }
        return resp;
      }).catch(function() { return caches.match('/index.html'); })
    );
    return;
  }
});
